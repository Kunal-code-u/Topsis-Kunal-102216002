# Topsis-Kunal-102216002

This Python package implements the TOPSIS (Technique for Order of Preference by Similarity to Ideal Solution) method for multi-criteria decision-making.

## Installation
Install the package from PyPI:
```bash
pip install Topsis-Kunal-102216002
